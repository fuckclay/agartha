# For start animation of summoning error
summon marker ~ ~ ~ {Tags:["totem.activator"]}