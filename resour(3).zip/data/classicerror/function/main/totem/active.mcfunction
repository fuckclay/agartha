# Active function
tag @s add active
execute if score error.summoned world matches 0 if score totem.playsound Settings matches 0 if score totem.particles Settings matches 0 run scoreboard players set totem.effects world 198
execute if score error.summoned world matches 0 if score totem.playsound Settings matches 0 if score totem.particles Settings matches 1 run scoreboard players set totem.effects world 75
execute if score error.summoned world matches 0 if score totem.playsound Settings matches 1 if score totem.particles Settings matches 0 run scoreboard players set totem.effects world 198
execute if score error.summoned world matches 0 if score totem.playsound Settings matches 1 if score totem.particles Settings matches 1 run scoreboard players set totem.effects world 1
execute if score error.summoned world matches 1 run scoreboard players set totem.effects world 198