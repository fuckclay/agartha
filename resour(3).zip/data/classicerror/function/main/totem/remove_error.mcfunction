# remove error from your world
function classicerror:main/totem/animate
scoreboard players set totem.deactivate world 1