# Main function
# Error
execute as @e[tag=error.head] at @s anchored eyes run tp @s ~ ~ ~ facing entity @p[gamemode=!spectator] eyes
execute as @e[tag=error.head] run data modify entity @s Pose.Head[0] set from entity @s Rotation[1]
execute as @e[tag=error.head.glow_eyes] run data modify entity @s Pose.Head[0] set from entity @n[tag=error.head] Pose.Head[0]
execute as @e[tag=error.head] at @n[tag=error.body] positioned ~ ~ ~ run tp @s ~ ~ ~
execute as @e[tag=error.head.glow_eyes] at @n[tag=error.head] positioned ~ ~ ~ run tp @s ~ ~ ~ ~ ~
execute as @e[tag=error.body] store result entity @s Rotation[0] float 1 run data get entity @n[tag=error.head] Rotation[0]
execute as @e[tag=error.body] at @s unless entity @n[tag=error.head,distance=..1] run tp @s ~ -500 ~
execute as @e[tag=error.head] at @s unless entity @n[tag=error.body,distance=..1] run tp @s ~ -500 ~
execute as @e[tag=error.head.glow_eyes] at @s unless entity @n[tag=error.head,distance=..1] run tp @s ~ -500 ~
execute as @e[tag=error.head] run data merge entity @s {equipment:{head:{id:"carrot_on_a_stick",components:{custom_model_data:{strings:["error.head"]}}}}}
execute as @e[tag=error.body] run data merge entity @s {equipment:{head:{id:"carrot_on_a_stick",components:{custom_model_data:{strings:["error.body"]}}}}}
execute as @e[tag=error.head.glow_eyes] run data merge entity @s {equipment:{head:{id:"carrot_on_a_stick",components:{custom_model_data:{strings:["error.glow_eyes"]}}}}}
execute as @e[tag=error.head] run data merge entity @s {Fire:0s}
execute as @e[tag=error.head,tag=!classicerror.exception] if score error.summoned world matches 0 as @e[tag=error.body] at @s run tp @s ~ -500 ~
execute as @e[tag=error.head.glow_eyes] at @s if score error.head.eyes.glow Settings matches 0 run tp @s ~ -500 ~
# Error near
execute as @e[tag=error.head,tag=error.near] at @s unless entity @p[distance=..80] run tp @s ~ -500 ~
execute as @a[gamemode=!spectator] at @s anchored eyes facing entity @n[tag=error.head,tag=error.near] eyes anchored feet positioned ^ ^ ^1 rotated as @s positioned ^ ^ ^-1 if entity @s[distance=..0.5] as @n[tag=error.head,tag=error.near] at @s if score error.death1.playsound Settings matches 1 run playsound classicerror:entity.error.death1 hostile @a ~ ~ ~ 4 0.9
execute as @a[gamemode=!spectator] at @s anchored eyes facing entity @n[tag=error.head,tag=error.near] eyes anchored feet positioned ^ ^ ^1 rotated as @s positioned ^ ^ ^-1 if entity @s[distance=..0.5] run advancement grant @s only classicerror:error/so_close
execute as @a[gamemode=!spectator] at @s anchored eyes facing entity @n[tag=error.head,tag=error.near] eyes anchored feet positioned ^ ^ ^1 rotated as @s positioned ^ ^ ^-1 if entity @s[distance=..0.5] as @n[tag=error.head,tag=error.near] at @s run function classicerror:main/error/kill
# Error far
execute as @e[tag=error.head,tag=error.far] at @s unless entity @p[distance=2..140] run tp @s ~ -500 ~
execute as @e[tag=error.head,tag=error.far] at @s unless entity @p[distance=2..140] as @p run advancement grant @s only classicerror:error/far_hide
execute as @a[gamemode=!spectator] at @s anchored eyes facing entity @n[tag=error.head,tag=error.far] eyes anchored feet positioned ^ ^ ^1 rotated as @s positioned ^ ^ ^-1 if entity @s[distance=..0.1] run scoreboard players set @s isLook.far 1
execute as @a[scores={isLook.far=1}] run scoreboard players add @s manyLook.far 1
execute as @a[scores={isLook.far=1}] run advancement grant @s only classicerror:error/so_far
execute as @a[scores={manyLook.far=370}] at @s if score error.death2.playsound Settings matches 1 run playsound classicerror:entity.error.death2 hostile @a ~ ~ ~ 2 0.7
execute as @a[scores={manyLook.far=501..}] at @s as @n[tag=error.head,tag=error.far] at @s run function classicerror:main/error/kill
execute as @a[scores={manyLook.far=501..}] run scoreboard players set @s isLook.far 0
execute as @a[scores={manyLook.far=501..}] run scoreboard players set @s manyLook.far 0
execute as @a unless entity @e[tag=error.far] run scoreboard players set @a manyLook.far 0
execute as @a unless entity @e[tag=error.far] run scoreboard players set @a isLook.far 0
# Error statute
execute as @a[scores={error.statue=1..}] at @s run summon armor_stand ~ ~ ~ {Tags:["statue.error.head","classicerror.exception"],Silent:true,NoGravity:true,Invulnerable:true,Invisible:true,Pose:{Head:[0.1f,0.1f,0.0f]}}
execute as @a[scores={error.statue=1..}] run scoreboard players set @s error.statue 0
execute as @e[tag=statue.error.head,tag=!bodied] at @s run summon armor_stand ~ ~ ~ {Tags:["statue.error.body","statue.herobrine"],Silent:true,Invisible:true,Invulnerable:true,NoBasePlate:true,NoGravity:true}
execute as @e[tag=statue.error.head,tag=!bodied] at @s if score error.head.eyes.glow Settings matches 1 run summon armor_stand ~ ~ ~ {Tags:["statue.error.head.glow_eyes"],Silent:true,Invisible:true,Invulnerable:true,NoBasePlate:true,NoGravity:true,Marker:true,HasVisualFire:true,Pose:{Head:[0.1f,0.1f,0f]}}
execute as @e[tag=statue.error.head,tag=!bodied] run tag @s add bodied
execute as @e[tag=statue.error.body] store result entity @s Rotation[0] float 0.01 run data get entity @n[tag=statue.error.head] Rotation[0] 100
execute as @e[tag=statue.error.head.glow_eyes] store result entity @s Rotation[0] float 0.01 run data get entity @n[tag=statue.error.head] Rotation[0] 100
execute as @e[tag=statue.error.head] at @s anchored eyes run tp @s ~ ~ ~ facing entity @p[gamemode=!spectator] eyes
execute as @e[tag=statue.error.head] run data modify entity @s Pose.Head[0] set from entity @s Rotation[1]
execute as @e[tag=statue.error.head.glow_eyes] at @s run data modify entity @s Pose.Head[0] set from entity @n[tag=statue.error.head] Pose.Head[0]
execute as @e[tag=statue.error.head] at @n[tag=statue.error.body] positioned ~ ~ ~ run tp @s ~ ~ ~
execute as @e[tag=statue.error.head.glow_eyes] at @n[tag=statue.error.head] positioned ~ ~ ~ run tp @s ~ ~ ~
execute as @e[tag=statue.error.body] at @s unless entity @n[tag=statue.error.head,distance=..1] run tp @s ~ -500 ~
execute as @e[tag=statue.error.head] at @s unless entity @n[tag=statue.error.body,distance=..1] run tp @s ~ -500 ~
execute as @e[tag=statue.error.head.glow_eyes] at @s unless entity @n[tag=statue.error.head,distance=..1] run tp @s ~ -500 ~
execute as @e[tag=statue.error.head] run data merge entity @s {equipment:{head:{id:"carrot_on_a_stick",components:{custom_model_data:{strings:["error.head"]}}}}}
execute as @e[tag=statue.error.body] run data merge entity @s {equipment:{head:{id:"carrot_on_a_stick",components:{custom_model_data:{strings:["error.body"]}}}}}
execute as @e[tag=statue.error.head.glow_eyes] run data merge entity @s {equipment:{head:{id:"carrot_on_a_stick",components:{custom_model_data:{strings:["error.glow_eyes"]}}}}}
execute as @e[tag=statue.error.head] run data merge entity @s {Fire:0s}
# Error spawn
execute as @r at @s if score error.summoned world matches 1 if score error.tick world matches 4099.. if predicate classicerror:error_spawn unless score totem.effects world matches 1..510 run function classicerror:main/error/summon
execute as @r at @s if score error.summoned world matches 1 if score error.tick world matches 1499.. if score isNight world matches 1 unless score totem.effects world matches 1..510 run function classicerror:main/error/summon
execute as @r at @s if score error.summoned world matches 1 if score error.tick world matches 3299.. if biome ~ ~ ~ #classicerror:common_spawn unless score totem.effects world matches 1..510 run function classicerror:main/error/summon

# Totem
execute as @a[scores={flintsteel.use=1..}] run scoreboard players set @s totem.active 1
execute as @a[scores={firecharge.use=1..}] run scoreboard players set @s totem.active 1
execute as @a[scores={totem.active=1..}] run function classicerror:main/raycast/totem/shoot
execute as @a[scores={flintsteel.use=1..}] run scoreboard players set @s flintsteel.use 0
execute as @a[scores={firecharge.use=1..}] run scoreboard players set @s firecharge.use 0
execute as @a[scores={totem.active=1..}] run scoreboard players set @s totem.active 0
execute as @e[tag=totem.activator,tag=!active,limit=1] at @s run function classicerror:main/totem/active
execute if score totem.effects world matches 1..510 run scoreboard players add totem.effects world 1
execute as @a at @s if score totem.effects world matches 3 if score totem.playsound Settings matches 1 if score totem.particles Settings matches 1 run playsound classicerror:entity.error.spawn_all hostile @a ~ ~ ~ 4 1
execute as @a at @s if score totem.particles Settings matches 0 if score totem.playsound Settings matches 1 if score totem.effects world matches 225 if score error.summoned world matches 0 run playsound classicerror:entity.error.spawn_part3 hostile @a ~ ~ ~ 4 1
execute as @e[tag=totem.activator,tag=active,limit=1] at @s if score totem.effects world matches 88..198 if score totem.particles Settings matches 1 align xyz positioned ~0.5 ~0.5 ~0.5 run particle minecraft:flame ~ ~1 ~ 0.25 0.375 0.25 0.12 30 normal
execute as @e[tag=totem.activator,tag=active,limit=1] at @s if score totem.effects world matches 210 if score totem.lightningbolt.strike Settings matches 1 align xyz positioned ~0.5 ~ ~0.5 run summon lightning_bolt ~ ~ ~
execute as @e[tag=totem.activator,tag=active,limit=1] at @s if score totem.effects world matches 234 if score totem.herobrine.spawn Settings matches 1 run tp @e[tag=error.body] ~ -500 ~
execute as @e[tag=totem.activator,tag=active,limit=1] at @s if score totem.effects world matches 235 if score totem.herobrine.spawn Settings matches 1 align xyz positioned ~0.5 ~ ~0.5 run summon armor_stand ~ ~ ~ {Tags:["error.head","classicerror.exception"],Silent:true,NoGravity:true,Invulnerable:true,Invisible:true,Pose:{Head:[0.1f,0.1f,0.0f]}}
execute as @e[tag=totem.activator,tag=active,limit=1] at @s if score totem.effects world matches 235 if score totem.herobrine.spawn Settings matches 1 align xyz positioned ~0.5 ~ ~0.5 run summon armor_stand ~ ~ ~ {Tags:["error.body"],Silent:true,Invisible:true,Invulnerable:true,NoBasePlate:true,NoGravity:true}
execute as @e[tag=totem.activator,tag=active,limit=1] at @s if score totem.effects world matches 235 if score error.head.eyes.glow Settings matches 1 align xyz positioned ~0.5 ~ ~0.5 run summon armor_stand ~ ~ ~ {Tags:["error.head.glow_eyes"],Silent:true,Invisible:true,Invulnerable:true,NoBasePlate:true,NoGravity:true,Marker:true,HasVisualFire:true,Pose:{Head:[0.1f,0.1f,0.0f]}}
execute as @e[tag=totem.activator,tag=active,limit=1] at @s if score totem.effects world matches 460 run execute as @e[tag=error.body] at @s run tp @s ~ -500 ~
execute as @e[tag=totem.activator,tag=active,limit=1] if score totem.effects world matches 460 run scoreboard players set error.totem world 1
execute as @e[tag=totem.activator,tag=active,limit=1] if score totem.effects world matches 510.. if score totem.deactivate world matches 1.. run scoreboard players set error.totem world 0
execute as @e[tag=totem.activator,tag=active,limit=1] at @s if score totem.effects world matches 465.. if score totem.deactivate world matches 1.. run fill ~-1 ~ ~-1 ~1 ~-2 ~1 air destroy
execute as @e[tag=totem.activator,tag=active,limit=1] at @s if score totem.effects world matches 235 if score totem.deactivate world matches 1.. run playsound minecraft:entity.ender_dragon.death hostile @a ~ ~ ~ 4 0.9
execute if score totem.effects world matches 510.. run advancement grant @a only classicerror:error/summon
execute if score totem.effects world matches 510.. if score totem.deactivate world matches 1 run advancement grant @a only classicerror:error/despawn
execute if score totem.effects world matches 510.. run kill @e[tag=totem.activator]
execute if score totem.effects world matches 510.. if score totem.deactivate world matches 1.. run scoreboard players set totem.deactivate world 0
execute if score totem.effects world matches 510.. run scoreboard players set totem.effects world 0
execute as @e[type=item,nbt={Item:{id:"minecraft:enchanted_golden_apple"}}] at @s if score error.summoned world matches 1 if block ~ ~ ~ fire if block ~ ~-1 ~ netherrack if block ~ ~-2 ~ #minecraft:planks if block ~ ~-2 ~1 gold_block if block ~ ~-2 ~-1 gold_block if block ~1 ~-2 ~ gold_block if block ~-1 ~-2 ~ gold_block if block ~1 ~-2 ~1 gold_block if block ~1 ~-2 ~-1 gold_block if block ~-1 ~-2 ~1 gold_block if block ~-1 ~-2 ~-1 gold_block if block ~1 ~-1 ~ redstone_torch if block ~-1 ~-1 ~ redstone_torch if block ~ ~-1 ~1 redstone_torch if block ~ ~-1 ~-1 redstone_torch unless block ~1 ~-1 ~1 redstone_torch unless block ~1 ~-1 ~-1 redstone_torch unless block ~-1 ~-1 ~1 redstone_torch unless block ~-1 ~-1 ~-1 redstone_torch run function classicerror:main/totem/remove_error

# Error Available	
execute if score error.spawn.always Settings matches 1 run scoreboard players set error.summoned world 1
execute if score error.spawn.always Settings matches 0 if score error.totem world matches 0 run scoreboard players set error.summoned world 0
execute if score error.totem world matches 1 run scoreboard players set error.summoned world 1


# Structures
execute if score structure.tick world matches 25999.. if predicate classicerror:default_str if score structure.place Settings matches 1 as @a at @s run function classicerror:main/structure/summon
execute if score structure.tick world matches 13999.. if predicate classicerror:summoned_str if score error.summoned world matches 1 if score structure.place Settings matches 1 as @r at @s run function classicerror:main/structure/summon

# Time
execute store result score tick world run time query daytime
execute if score tick world matches 12542..23459 run scoreboard players set isNight world 1
execute unless score tick world matches 12542..23459 run scoreboard players set isNight world 0
execute if score error.summoned world matches 1 run scoreboard players add error.tick world 1
scoreboard players add structure.tick world 1
execute if score error.tick world matches 4100.. run scoreboard players set error.tick world 0
execute if score structure.tick world matches 26000.. run scoreboard players set structure.tick world 0
execute if score error.summoned world matches 1 if score structure.tick world matches 14000.. run scoreboard players set structure.tick world 0
execute if score error.tick world matches 1500.. if score isNight world matches 1 run scoreboard players set error.tick world 0
execute if score error.summoned world matches 0 run scoreboard players set error.tick world 0

# Settings
scoreboard players enable @a ClassicError.Main.Settings
execute as @a[scores={ClassicError.Main.Settings=1..}] run function classicerror:config/open
execute as @a[scores={ClassicError.Main.Settings=1..}] run scoreboard players set @s ClassicError.Main.Settings 0

# Bed
execute as @a at @s anchored eyes if block ^ ^ ^-0.5 #minecraft:beds run scoreboard players set @s isSleeping 1
execute as @a at @s anchored eyes unless block ^ ^ ^-0.5 #minecraft:beds run scoreboard players set @s isSleeping 0
execute as @a[scores={isSleeping=1}] at @s unless score @s error.bed.spawn matches 20.. run scoreboard players add @s error.bed.spawn 1
execute as @a[scores={error.bed.spawn=19}] if predicate classicerror:error_bed if score error.summoned world matches 1 run scoreboard players set allow error.bed.spawn 1
execute as @a[scores={error.bed.spawn=19}] if score allow error.bed.spawn matches 1 if score bed.error.blindness Settings matches 1 run effect give @s blindness 10 0 true
execute as @a[scores={error.bed.spawn=19}] at @s align xyz positioned ~0.5 ~ ~0.5 unless entity @e[tag=error.head] if score allow error.bed.spawn matches 1 if score bed.playsound Settings matches 1 run playsound minecraft:entity.wither.spawn hostile @a ~ ~ ~ 1 0.1
execute as @r[scores={isSleeping=1}] at @s if block ~ ~-0.5 ~ #minecraft:beds[facing=south] align xyz positioned ~0.5 ~ ~0.5 if score bed.error.particles Settings matches 1 if score allow error.bed.spawn matches 1 run particle smoke ~ ~1.1 ~-2 0.0125 0.025 0.0125 0.1 1 normal
execute as @r[scores={isSleeping=1}] at @s if block ~ ~-0.5 ~ #minecraft:beds[facing=north] align xyz positioned ~0.5 ~ ~0.5 if score bed.error.particles Settings matches 1 if score allow error.bed.spawn matches 1 run particle smoke ~ ~1.1 ~2 0.0125 0.025 0.0125 0.1 1 normal
execute as @r[scores={isSleeping=1}] at @s if block ~ ~-0.5 ~ #minecraft:beds[facing=east] align xyz positioned ~0.5 ~ ~0.5 if score bed.error.particles Settings matches 1 if score allow error.bed.spawn matches 1 run particle smoke ~-2 ~1.1 ~ 0.0125 0.025 0.0125 0.1 1 normal
execute as @r[scores={isSleeping=1}] at @s if block ~ ~-0.5 ~ #minecraft:beds[facing=west] align xyz positioned ~0.5 ~ ~0.5 if score bed.error.particles Settings matches 1 if score allow error.bed.spawn matches 1 run particle smoke ~2 ~1.1 ~ 0.0125 0.025 0.0125 0.1 1 normal
execute as @r[scores={error.bed.spawn=19}] at @s if block ~ ~-0.5 ~ #minecraft:beds[facing=south] align xyz positioned ~0.5 ~ ~0.5 unless entity @e[tag=error.head] if score allow error.bed.spawn matches 1 if score bed.error.spawn Settings matches 1 run summon armor_stand ~ ~ ~-2 {Tags:["error.head"],Silent:true,Invulnerable:true,Pose:{Head:[0.1f,0.1f,0.0f]},Invisible:true,Rotation:[0f,0f]}
execute as @r[scores={error.bed.spawn=19}] at @s if block ~ ~-0.5 ~ #minecraft:beds[facing=south] align xyz positioned ~0.5 ~ ~0.5 unless entity @e[tag=error.body] if score allow error.bed.spawn matches 1 if score bed.error.spawn Settings matches 1 run summon armor_stand ~ ~ ~-2 {Tags:["error.body"],NoBasePlate:true,Invisible:true,Invulnerable:true,Silent:true,Rotation:[0f,0f]}
execute as @r[scores={error.bed.spawn=19}] at @s if block ~ ~-0.5 ~ #minecraft:beds[facing=south] align xyz positioned ~0.5 ~ ~0.5 unless entity @e[tag=error.head.glow_eyes] if score allow error.bed.spawn matches 1 if score error.head.eyes.glow Settings matches 1 if score bed.error.spawn Settings matches 1 run summon armor_stand ~ ~ ~-2 {Tags:["error.head.glow_eyes"],NoBasePlate:true,Invisible:true,Invulnerable:true,Silent:true,Rotation:[0f,0f],Pose:{Head:[0.1f,0.1f,0.0f]},HasVisualFire:true,Marker:true}
execute as @r[scores={error.bed.spawn=19}] at @s if block ~ ~-0.5 ~ #minecraft:beds[facing=north] align xyz positioned ~0.5 ~ ~0.5 unless entity @e[tag=error.head] if score allow error.bed.spawn matches 1 if score bed.error.spawn Settings matches 1 run summon armor_stand ~ ~ ~2 {Tags:["error.head"],Silent:true,Invulnerable:true,Pose:{Head:[0.1f,0.1f,0.0f]},Invisible:true,Rotation:[180f,0f]}
execute as @r[scores={error.bed.spawn=19}] at @s if block ~ ~-0.5 ~ #minecraft:beds[facing=north] align xyz positioned ~0.5 ~ ~0.5 unless entity @e[tag=error.body] if score allow error.bed.spawn matches 1 if score bed.error.spawn Settings matches 1 run summon armor_stand ~ ~ ~2 {Tags:["error.body"],NoBasePlate:true,Invisible:true,Invulnerable:true,Silent:true,Rotation:[180f,0f]}
execute as @r[scores={error.bed.spawn=19}] at @s if block ~ ~-0.5 ~ #minecraft:beds[facing=north] align xyz positioned ~0.5 ~ ~0.5 unless entity @e[tag=error.head.glow_eyes] if score allow error.bed.spawn matches 1 if score error.head.eyes.glow Settings matches 1 if score bed.error.spawn Settings matches 1 run summon armor_stand ~ ~ ~2 {Tags:["error.head.glow_eyes"],NoBasePlate:true,Invisible:true,Invulnerable:true,Silent:true,Rotation:[180f,0f],Pose:{Head:[0.1f,0.1f,0.0f]},HasVisualFire:true,Marker:true}
execute as @r[scores={error.bed.spawn=19}] at @s if block ~ ~-0.5 ~ #minecraft:beds[facing=east] align xyz positioned ~0.5 ~ ~0.5 unless entity @e[tag=error.head] if score allow error.bed.spawn matches 1 if score bed.error.spawn Settings matches 1 run summon armor_stand ~-2 ~ ~ {Tags:["error.head"],Silent:true,Invulnerable:true,Pose:{Head:[0.1f,0.1f,0.0f]},Invisible:true,Rotation:[90f,0f]}
execute as @r[scores={error.bed.spawn=19}] at @s if block ~ ~-0.5 ~ #minecraft:beds[facing=east] align xyz positioned ~0.5 ~ ~0.5 unless entity @e[tag=error.body] if score allow error.bed.spawn matches 1 if score bed.error.spawn Settings matches 1 run summon armor_stand ~-2 ~ ~ {Tags:["error.body"],NoBasePlate:true,Invisible:true,Invulnerable:true,Silent:true,Rotation:[90f,0f]}
execute as @r[scores={error.bed.spawn=19}] at @s if block ~ ~-0.5 ~ #minecraft:beds[facing=east] align xyz positioned ~0.5 ~ ~0.5 unless entity @e[tag=error.head.glow_eyes] if score allow error.bed.spawn matches 1 if score error.head.eyes.glow Settings matches 1 if score bed.error.spawn Settings matches 1 run summon armor_stand ~-2 ~ ~ {Tags:["error.head.glow_eyes"],NoBasePlate:true,Invisible:true,Invulnerable:true,Silent:true,Rotation:[90f,0f],Pose:{Head:[0.1f,0.1f,0.0f]},HasVisualFire:true,Marker:true}
execute as @r[scores={error.bed.spawn=19}] at @s if block ~ ~-0.5 ~ #minecraft:beds[facing=west] align xyz positioned ~0.5 ~ ~0.5 unless entity @e[tag=error.head] if score allow error.bed.spawn matches 1 if score bed.error.spawn Settings matches 1 run summon armor_stand ~2 ~ ~ {Tags:["error.head"],Silent:true,Invulnerable:true,Pose:{Head:[0.1f,0.1f,0.0f]},Invisible:true,Rotation:[270f,0f]}
execute as @r[scores={error.bed.spawn=19}] at @s if block ~ ~-0.5 ~ #minecraft:beds[facing=west] align xyz positioned ~0.5 ~ ~0.5 unless entity @e[tag=error.body] if score allow error.bed.spawn matches 1 if score bed.error.spawn Settings matches 1 run summon armor_stand ~2 ~ ~ {Tags:["error.body"],NoBasePlate:true,Invisible:true,Invulnerable:true,Silent:true,Rotation:[270f,0f]}
execute as @r[scores={error.bed.spawn=19}] at @s if block ~ ~-0.5 ~ #minecraft:beds[facing=west] align xyz positioned ~0.5 ~ ~0.5 unless entity @e[tag=error.head.glow_eyes] if score allow error.bed.spawn matches 1 if score error.head.eyes.glow Settings matches 1 if score bed.error.spawn Settings matches 1 run summon armor_stand ~2 ~ ~ {Tags:["error.head.glow_eyes"],NoBasePlate:true,Invisible:true,Invulnerable:true,Silent:true,Rotation:[270f,0f],Pose:{Head:[0.1f,0.1f,0.0f]},HasVisualFire:true,Marker:true}
execute as @a if score allow error.bed.spawn matches 1 if score @s isSleeping matches 0 run scoreboard players set allow error.bed.spawn 0
execute as @a[scores={isSleeping=0}] if score @s error.bed.spawn matches 20 as @e[tag=error.body] at @s run tp @s ~ -500 ~
execute as @a[scores={isSleeping=0}] if score @s error.bed.spawn matches 20 as @e[tag=error.head.glow_eyes] at @s run tp @s ~ -500 ~
execute as @a[scores={isSleeping=0}] run scoreboard players set @s error.bed.spawn 0