# Shoot raycast (Start raycast)
tag @s add raycaster
execute at @s anchored eyes positioned ^ ^ ^ run function classicerror:main/raycast/totem/loop
tag @s remove raycaster