# Summon error
execute store result score error.type world run random value 1..3
execute if score error.type world matches 1..2 run function classicerror:main/error/near/spawn
execute if score error.type world matches 3 run function classicerror:main/error/far/spawn
scoreboard players set error.type world 0
advancement grant @s only classicerror:error/err_spawns

scoreboard players set error.tick world 0