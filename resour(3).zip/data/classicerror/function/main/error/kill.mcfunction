# Kill every Herobrine
tp @e[tag=error.body] ~ -500 ~
tp @e[tag=error.head] ~ -500 ~
tp @e[tag=error.head.glow_eyes] ~ -500 ~