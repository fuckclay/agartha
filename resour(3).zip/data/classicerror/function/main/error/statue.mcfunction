scoreboard players enable @s error.statue
trigger error.statue
tag @s add classicerror.debug