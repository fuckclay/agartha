# Spawn Error
function classicerror:main/error/kill
summon armor_stand ~ ~ ~ {Tags:["error.spawn.near"],Small:true,Invisible:true}
execute unless dimension minecraft:the_nether run spreadplayers ~ ~ 2 5 false @n[tag=error.spawn.near]
execute if dimension minecraft:the_nether run tp @n[tag=error.spawn.near] ^ ^ ^-2
execute if dimension minecraft:the_nether run function classicerror:main/error/near/alt
execute store result score error.posY world run data get entity @s Pos[1]
execute unless dimension minecraft:the_nether unless dimension minecraft:the_end if score error.posY world matches ..63 run function classicerror:main/error/near/alt
execute as @e[tag=error.spawn.near] at @s if block ~ ~-1 ~ #classicerror:inside run tp @s ~ ~-1 ~
execute at @n[tag=error.spawn.near] run summon armor_stand ~ ~ ~ {Tags:["error.head","error.near"],Silent:true,NoGravity:true,Invulnerable:true,Invisible:true,Pose:{Head:[0.1f,0.1f,0f]}}
execute at @n[tag=error.spawn.near] run summon armor_stand ~ ~ ~ {Tags:["error.body"],Silent:true,Invisible:true,Invulnerable:true,NoBasePlate:true,NoGravity:true,NoGravity:true}
execute at @n[tag=error.spawn.near] if score error.head.eyes.glow Settings matches 1 run summon armor_stand ~ ~ ~ {Tags:["error.head.glow_eyes"],Silent:true,Invisible:true,Invulnerable:true,NoBasePlate:true,NoGravity:true,Marker:true,HasVisualFire:true,Pose:{Head:[0.1f,0.1f,0.0f]}}
kill @n[tag=error.spawn.near]
scoreboard players set error.posY world 0