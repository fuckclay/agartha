# Run Herobrine in nether
execute store result score error.posX world run data get entity @s Pos[0] 1000
execute store result score error.posY world run data get entity @s Pos[1] 1000 
execute store result score error.posZ world run data get entity @s Pos[2] 1000
execute if dimension minecraft:the_nether store result score error.spr.posX world run random value -5000..5000
execute if dimension minecraft:the_nether store result score error.spr.posZ world run random value -5000..5000
execute if dimension minecraft:overworld store result score error.spr.posX world run random value -2000..2000
execute if dimension minecraft:overworld store result score error.spr.posZ world run random value -2000..2000
scoreboard players operation error.posX world += error.spr.posX world
scoreboard players operation error.posZ world += error.spr.posZ world
execute store result entity @n[tag=error.spawn.near] Pos[0] double 0.001 run scoreboard players get error.posX world
execute store result entity @n[tag=error.spawn.near] Pos[1] double 0.001 run scoreboard players get error.posY world
execute store result entity @n[tag=error.spawn.near] Pos[2] double 0.001 run scoreboard players get error.posZ world
scoreboard players set error.posX world 0
scoreboard players set error.posY world 0
scoreboard players set error.posZ world 0
scoreboard players set error.spr.posX world 0
scoreboard players set error.spr.posZ world 0