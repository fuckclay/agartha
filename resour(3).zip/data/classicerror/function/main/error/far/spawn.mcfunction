# Spawn Error
function classicerror:main/error/kill
execute unless dimension minecraft:the_nether run summon armor_stand ~ ~ ~ {Tags:["error.spawn.far"],Small:true,Invisible:true}
execute if dimension minecraft:the_nether run function classicerror:main/error/near/spawn
execute store result score error.posY world run data get entity @s Pos[1]
execute unless dimension minecraft:the_nether unless dimension minecraft:the_end if score error.posY world matches ..63 run function classicerror:main/error/near/spawn
execute if dimension minecraft:overworld run function classicerror:main/error/near/alt
spreadplayers ~ ~ 5 50 false @n[tag=error.spawn.far]
execute as @e[tag=error.spawn.far] at @s if block ~ ~-1 ~ #classicerror:inside run tp @s ~ ~-1 ~
execute at @n[tag=error.spawn.far] run summon armor_stand ~ ~ ~ {Tags:["error.head","error.far"],CustomName:{"text":"Error"},Silent:true,NoGravity:true,Invulnerable:true,Invisible:true,NoBasePlate:true,Pose:{Head:[0.1f,0.1f,0.0f]}}
execute at @n[tag=error.spawn.far] run summon armor_stand ~ ~ ~ {Tags:["error.body"],CustomName:{"text":"Error"},Silent:true,Invisible:true,Invulnerable:true,NoBasePlate:true,NoGravity:true}
execute at @n[tag=error.spawn.far] if score error.head.eyes.glow Settings matches 1 run summon armor_stand ~ ~ ~ {Tags:["error.head.glow_eyes"],Silent:true,Invisible:true,Invulnerable:true,NoBasePlate:true,NoGravity:true,Marker:true,HasVisualFire:true,Pose:{Head:[0.1f,0.1f,0.0f]}}
kill @n[tag=error.spawn.far]
scoreboard players set error.posY world 0