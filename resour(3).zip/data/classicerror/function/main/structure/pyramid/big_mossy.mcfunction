# Summon Small Mossy Pyramid
summon marker ~ ~ ~ {Tags:["sbp.spawn"]}
spreadplayers ~ ~ 4 150 false @e[tag=sbp.spawn]
execute as @e[tag=sbp.spawn] at @s positioned over motion_blocking_no_leaves run tp @s ~ ~ ~
execute at @e[tag=sbp.spawn,sort=random,limit=1] run place template classicerror:pyramid/big_mossy_pyramid
execute as @e[tag=sbp.spawn] as @a[tag=classicerror.debug] run say BigMossyPyramid spawned
kill @e[tag=sbp.spawn]