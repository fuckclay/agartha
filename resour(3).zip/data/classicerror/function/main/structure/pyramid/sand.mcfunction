# Summon Sand pyramid
summon marker ~ ~ ~ {Tags:["sp.spawn"]}
execute store result score posX structure run data get entity @e[tag=sp.spawn,limit=1] Pos[0]
execute store result score posZ structure run data get entity @e[tag=sp.spawn,limit=1] Pos[2]
execute store result score str.posX structure run random value -100..100
execute store result score str.posZ structure run random value -100..100
scoreboard players operation posX structure += str.posX structure
scoreboard players operation posZ structure += str.posZ structure
execute store result entity @e[tag=sp.spawn,limit=1] Pos[0] double 1 run scoreboard players get posX structure
execute store result entity @e[tag=sp.spawn,limit=1] Pos[2] double 1 run scoreboard players get posZ structure
execute as @e[tag=sp.spawn] at @s positioned ~ 61 ~ if biome ~ ~ ~ #classicerror:is_water run place template classicerror:pyramid/sand_pyramid
scoreboard players set str.posX structure 0
scoreboard players set str.posZ structure 0
scoreboard players set posX structure 0
scoreboard players set posZ structure 0
execute as @e[tag=sp.spawn] as @a[tag=classicerror.debug] run say SandPyramid spawned
kill @e[tag=sp.spawn]