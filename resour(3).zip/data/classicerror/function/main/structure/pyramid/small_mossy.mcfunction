# Summon Small Mossy Pyramid
summon marker ~ ~ ~ {Tags:["smp.spawn"]}
spreadplayers ~ ~ 4 150 false @e[tag=smp.spawn]
execute as @e[tag=smp.spawn] at @s positioned over motion_blocking_no_leaves run tp @s ~ ~ ~
execute at @e[tag=smp.spawn,sort=random,limit=1] run place template classicerror:pyramid/small_mossy_pyramid
execute as @e[tag=smp.spawn] as @a[tag=classicerror.debug] run say SmallMossyPyramid spawned
kill @e[tag=smp.spawn]