summon marker ~ ~ ~ {Tags:["fp"]}
spreadplayers ~ ~ 5 150 false @e[tag=fp]
execute as @e[tag=fp] at @s positioned over motion_blocking_no_leaves run tp @s ~ ~ ~
execute as @e[tag=fp,limit=1] at @s run fill ~-13 ~-8 ~-12 ~13 ~18 ~15 air replace #minecraft:leaves
execute as @e[tag=fp] as @a[tag=classicerror.debug] run say NoLeaves spawned
kill @e[tag=fp]