# Summon cave of type 1
summon marker ~ ~ ~ {Tags:["c.t1.spawn","c.spawn"]}
execute as @e[tag=c.t1.spawn] store result score posX structure run data get entity @s Pos[0]
execute as @e[tag=c.t1.spawn] store result score posZ structure run data get entity @s Pos[2]
execute store result score str.posX structure run random value -150..150
execute store result score str.posY structure run random value -64..80
execute store result score str.posZ structure run random value -150..150
scoreboard players operation posX structure += str.posX structure
scoreboard players operation posZ structure += str.posZ structure
execute as @e[tag=c.t1.spawn] store result entity @s Pos[0] double 1 run scoreboard players get posX structure
execute as @e[tag=c.t1.spawn] store result entity @s Pos[1] double 1 run scoreboard players get str.posY structure
execute as @e[tag=c.t1.spawn] store result entity @s Pos[2] double 1 run scoreboard players get posZ structure
execute as @e[tag=c.t1.spawn] at @s run fill ~ ~ ~ ~30 ~1 ~1 air replace #classicerror:caves_block
execute as @e[tag=c.t1.spawn] at @s if block ~ ~1 ~-1 #classicerror:caves_block if score structure.caves.redstone_torch.place Settings matches 1 run setblock ~ ~1 ~ redstone_wall_torch[facing=south] replace
execute as @e[tag=c.t1.spawn] at @s if block ~10 ~1 ~-1 #classicerror:caves_block if score structure.caves.redstone_torch.place Settings matches 1 run setblock ~10 ~1 ~ redstone_wall_torch[facing=south] replace
execute as @e[tag=c.t1.spawn] at @s if block ~20 ~1 ~-1 #classicerror:caves_block if score structure.caves.redstone_torch.place Settings matches 1 run setblock ~20 ~1 ~ redstone_wall_torch[facing=south] replace
execute as @e[tag=c.t1.spawn] at @s if block ~30 ~1 ~-1 #classicerror:caves_block if score structure.caves.redstone_torch.place Settings matches 1 run setblock ~30 ~1 ~ redstone_wall_torch[facing=south] replace
scoreboard players set posX structure 0
scoreboard players set posZ structure 0
scoreboard players set str.posX structure 0
scoreboard players set str.posY structure 0
scoreboard players set str.posZ structure 0
execute as @e[tag=c.t1.spawn] as @a[tag=classicerror.debug] run say Caves.Type1 spawned
kill @e[tag=c.t1.spawn]