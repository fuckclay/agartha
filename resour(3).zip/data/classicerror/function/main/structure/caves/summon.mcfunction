# Summon caves
execute store result score caves.type structure run random value 1..4
execute if score caves.type structure matches 1 run function classicerror:main/structure/caves/type1
execute if score caves.type structure matches 2 run function classicerror:main/structure/caves/type2
execute if score caves.type structure matches 3 run function classicerror:main/structure/caves/type3
execute if score caves.type structure matches 4 run function classicerror:main/structure/caves/type4
scoreboard players set caves.type structure 0