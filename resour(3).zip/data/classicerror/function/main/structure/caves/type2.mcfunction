# Summon cave of type 2
summon marker ~ ~ ~ {Tags:["c.t2.spawn","c.spawn"]}
execute as @e[tag=c.t2.spawn] store result score posX structure run data get entity @s Pos[0]
execute as @e[tag=c.t2.spawn] store result score posZ structure run data get entity @s Pos[2]
execute store result score str.posX structure run random value -150..150
execute store result score str.posY structure run random value -64..80
execute store result score str.posZ structure run random value -150..150
scoreboard players operation posX structure += str.posX structure
scoreboard players operation posZ structure += str.posZ structure
execute as @e[tag=c.t2.spawn] store result entity @s Pos[0] double 1 run scoreboard players get posX structure
execute as @e[tag=c.t2.spawn] store result entity @s Pos[1] double 1 run scoreboard players get str.posY structure
execute as @e[tag=c.t2.spawn] store result entity @s Pos[2] double 1 run scoreboard players get posZ structure
execute as @e[tag=c.t2.spawn] at @s run fill ~ ~ ~ ~1 ~1 ~-30 air replace #classicerror:caves_block
execute as @e[tag=c.t2.spawn] at @s if block ~-1 ~1 ~ #classicerror:caves_block if score structure.caves.redstone_torch.place Settings matches 1 run setblock ~ ~1 ~ redstone_wall_torch[facing=east] replace
execute as @e[tag=c.t2.spawn] at @s if block ~-1 ~1 ~-10 #classicerror:caves_block if score structure.caves.redstone_torch.place Settings matches 1 run setblock ~ ~1 ~-10 redstone_wall_torch[facing=east] replace
execute as @e[tag=c.t2.spawn] at @s if block ~-1 ~1 ~-20 #classicerror:caves_block if score structure.caves.redstone_torch.place Settings matches 1 run setblock ~ ~1 ~-20 redstone_wall_torch[facing=east] replace
execute as @e[tag=c.t2.spawn] at @s if block ~-1 ~1 ~-30 #classicerror:caves_block if score structure.caves.redstone_torch.place Settings matches 1 run setblock ~ ~1 ~-30 redstone_wall_torch[facing=east] replace
scoreboard players set posX structure 0
scoreboard players set posZ structure 0
scoreboard players set str.posX structure 0
scoreboard players set str.posY structure 0
scoreboard players set str.posZ structure 0
execute as @e[tag=c.t2.spawn] as @a[tag=classicerror.debug] run say Caves.Type2 spawned
kill @e[tag=c.t2.spawn]