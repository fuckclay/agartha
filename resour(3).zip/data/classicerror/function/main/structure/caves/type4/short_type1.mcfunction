# Summon part of type 4 - type 1
execute as @e[tag=c.t4.spawn] at @s run fill ~ ~ ~ ~15 ~1 ~1 air replace #classicerror:caves_block
execute as @e[tag=c.t4.spawn] at @s if block ~2 ~1 ~-1 #classicerror:caves_block if score structure.caves.redstone_torch.place Settings matches 1 run setblock ~2 ~1 ~ redstone_wall_torch[facing=south] replace
execute as @e[tag=c.t4.spawn] at @s if block ~9 ~1 ~-1 #classicerror:caves_block if score structure.caves.redstone_torch.place Settings matches 1 run setblock ~9 ~1 ~ redstone_wall_torch[facing=south] replace
execute as @e[tag=c.t4.spawn] at @s if block ~15 ~1 ~-1 #classicerror:caves_block if score structure.caves.redstone_torch.place Settings matches 1 run setblock ~15 ~1 ~ redstone_wall_torch[facing=south] replace