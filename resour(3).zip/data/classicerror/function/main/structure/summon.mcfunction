# Summon a structure with available settings
execute store result score str structure run random value 1..5
execute if score str structure matches 1 run function classicerror:main/structure/caves/summon
execute if score str structure matches 2 run function classicerror:main/structure/pyramid/small_mossy
execute if score str structure matches 3 run function classicerror:main/structure/pyramid/big_mossy
execute if score str structure matches 4 run function classicerror:main/structure/pyramid/sand
execute if score str structure matches 5 run function classicerror:main/structure/forest/no_leaves

# Reset variables after function
scoreboard players set str structure 0