# Load function
scoreboard objectives add isLook.far dummy
scoreboard objectives add manyLook.far dummy
scoreboard objectives add totem.active dummy
scoreboard objectives add distance dummy
scoreboard objectives add world dummy
scoreboard objectives add Settings dummy
scoreboard objectives add isSleeping dummy
scoreboard objectives add error.bed.spawn dummy
scoreboard objectives add structure dummy
scoreboard objectives add error.statue trigger
scoreboard objectives add ClassicError.Main.Settings trigger
scoreboard objectives add flintsteel.use minecraft.used:minecraft.flint_and_steel
scoreboard objectives add firecharge.use minecraft.used:minecraft.fire_charge
scoreboard players add totem.effects world 0
scoreboard players add error.summoned world 0
scoreboard players add totem.deactivate world 0
scoreboard players add error.type world 0
scoreboard players add structure.tick world 0
scoreboard players add error.posX world 0
scoreboard players add error.posY world 0
scoreboard players add error.posZ world 0
scoreboard players add error.spr.posX world 0
scoreboard players add error.spr.posZ world 0
scoreboard players add tick world 0
scoreboard players add error.totem world 0 
scoreboard players add allow error.bed.spawn 0
scoreboard players add str.posX structure 0
scoreboard players add str.posZ structure 0
scoreboard players add posX structure 0
scoreboard players add posZ structure 0
scoreboard players add str.posY structure 0
scoreboard players add str structure 0
scoreboard players add caves.type structure 0
scoreboard players add caves.type4.type structure 0
execute unless score start Settings matches 2 run scoreboard players add start Settings 1
execute if score start Settings matches 1 run scoreboard players set totem.lightningbolt.strike Settings 1
execute if score start Settings matches 1 run scoreboard players set totem.particles Settings 0
execute if score start Settings matches 1 run scoreboard players set totem.herobrine.spawn Settings 1
execute if score start Settings matches 1 run scoreboard players set totem.playsound Settings 0
execute if score start Settings matches 1 run scoreboard players set bed.error.spawn Settings 1
execute if score start Settings matches 1 run scoreboard players set bed.error.particles Settings 0
execute if score start Settings matches 1 run scoreboard players set bed.playsound Settings 0
execute if score start Settings matches 1 run scoreboard players set bed.error.blindness Settings 1
execute if score start Settings matches 1 run scoreboard players set structure.place Settings 1
execute if score start Settings matches 1 run scoreboard players set error.death1.playsound Settings 0
execute if score start Settings matches 1 run scoreboard players set error.death2.playsound Settings 0
execute if score start Settings matches 1 run scoreboard players set structure.caves.redstone_torch.place Settings 0
execute if score start Settings matches 1 run scoreboard players set error.head.eyes.glow Settings 0
execute if score start Settings matches 1 run scoreboard players set error.spawn.always Settings 0