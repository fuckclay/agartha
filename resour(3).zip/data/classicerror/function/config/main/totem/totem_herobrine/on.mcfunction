scoreboard players set totem.herobrine.spawn Settings 1
dialog show @s classicerror:totem/totem_herobrine