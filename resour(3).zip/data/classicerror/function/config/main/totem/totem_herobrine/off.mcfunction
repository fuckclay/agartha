scoreboard players set totem.herobrine.spawn Settings 0
dialog show @s classicerror:totem/totem_herobrine