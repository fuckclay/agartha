scoreboard players set totem.particles Settings 1
dialog show @s classicerror:totem/particles