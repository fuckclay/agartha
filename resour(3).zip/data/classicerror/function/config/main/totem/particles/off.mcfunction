scoreboard players set totem.particles Settings 0
dialog show @s classicerror:totem/particles