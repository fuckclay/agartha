scoreboard players set totem.lightningbolt.strike Settings 0
dialog show @s classicerror:totem/lightning_bolt