scoreboard players set totem.lightningbolt.strike Settings 1
dialog show @s classicerror:totem/lightning_bolt