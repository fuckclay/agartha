scoreboard players set totem.playsound Settings 0
dialog show @s classicerror:totem/playsound