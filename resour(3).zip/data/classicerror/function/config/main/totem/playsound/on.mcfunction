scoreboard players set totem.playsound Settings 1
dialog show @s classicerror:totem/playsound