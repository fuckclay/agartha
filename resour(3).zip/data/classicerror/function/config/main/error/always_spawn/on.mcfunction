scoreboard players set error.spawn.always Settings 1
dialog show @s classicerror:error/always_spawn