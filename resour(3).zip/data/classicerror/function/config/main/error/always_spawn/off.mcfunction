scoreboard players set error.spawn.always Settings 0
dialog show @s classicerror:error/always_spawn