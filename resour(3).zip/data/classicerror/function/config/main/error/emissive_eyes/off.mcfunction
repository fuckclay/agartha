scoreboard players set error.head.eyes.glow Settings 0
dialog show @s classicerror:error/emissive_eyes