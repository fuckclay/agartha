scoreboard players set error.head.eyes.glow Settings 1
dialog show @s classicerror:error/emissive_eyes