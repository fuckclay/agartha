scoreboard players set error.death2.playsound Settings 0
dialog show @s classicerror:error/death_sounds