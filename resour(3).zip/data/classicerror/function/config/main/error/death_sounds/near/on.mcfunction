scoreboard players set error.death1.playsound Settings 1
dialog show @s classicerror:error/death_sounds