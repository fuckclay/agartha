scoreboard players set error.death2.playsound Settings 1
dialog show @s classicerror:error/death_sounds