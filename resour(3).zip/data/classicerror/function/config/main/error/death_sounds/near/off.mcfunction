scoreboard players set error.death1.playsound Settings 0
dialog show @s classicerror:error/death_sounds