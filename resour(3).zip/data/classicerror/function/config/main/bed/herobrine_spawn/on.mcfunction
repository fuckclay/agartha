scoreboard players set bed.error.spawn Settings 1
dialog show @s classicerror:bed/herobrine_spawn