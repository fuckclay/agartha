scoreboard players set bed.error.spawn Settings 0
dialog show @s classicerror:bed/herobrine_spawn