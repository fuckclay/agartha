scoreboard players set bed.error.particles Settings 1
dialog show @s classicerror:bed/particles