scoreboard players set bed.error.particles Settings 0
dialog show @s classicerror:bed/particles