scoreboard players set bed.error.blindness Settings 0
dialog show @s classicerror:bed/herobrine_blindness