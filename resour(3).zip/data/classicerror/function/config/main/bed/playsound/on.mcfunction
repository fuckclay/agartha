scoreboard players set bed.playsound Settings 1
dialog show @s classicerror:bed/playsound