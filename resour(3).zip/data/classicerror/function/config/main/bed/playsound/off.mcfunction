scoreboard players set bed.playsound Settings 0
dialog show @s classicerror:bed/playsound