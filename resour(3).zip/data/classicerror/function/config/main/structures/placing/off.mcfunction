scoreboard players set structure.place Settings 0
dialog show @s classicerror:structures/placing