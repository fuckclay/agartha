scoreboard players set structure.place Settings 1
dialog show @s classicerror:structures/placing