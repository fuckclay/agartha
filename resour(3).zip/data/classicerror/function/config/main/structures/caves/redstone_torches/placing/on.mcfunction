scoreboard players set structure.caves.redstone_torch.place Settings 1
dialog show @s classicerror:structures/caves/redstone_torches