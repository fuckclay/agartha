scoreboard players set structure.caves.redstone_torch.place Settings 0
dialog show @s classicerror:structures/caves/redstone_torches